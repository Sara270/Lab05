package org.eclipse.che.examples;

public class HelloWorld {
    public static void main(String... argvs) {
        String a = "Java";
        System.out.println("Labboratorio_5 " + a + "!");
        
        Node a1 = new Node();
        a1.setPropiedad("GUA");
        
        Node b = new Node();
        b.setPropiedad("MEX");
        a1.setNext(b);
    
        Node c =new Node();
        c.setPropiedad("USA");
        a1.getNext().setNext(c);
        
         Node d = new Node();
        d.setPropiedad("ESP");
        a1.getNext().getNext().setNext(d);
        
        System.out.println(a1.getPropiedad());
        System.out.println(a1.getNext().getPropiedad());
        System.out.println(a1.getNext().getNext().getPropiedad());
        System.out.println(a1.getNext().getNext().getNext().getPropiedad());
        
        
        
    SinglelyLinkedList lista = new SinglelyLinkedList();
    lista.addFirst("GUA");
    lista.addLast("ARG");
    lista.addLast("BRA");
    
    System.out.println(lista.first());
    System.out.println(lista.last());
    String valor = lista.removeFirst();
    
    
    while(valor == null){
        System.out.println(valor);
        valor= lista.removeFirst();
    }
    
    }
    private static class Node{
        private String propiedad;
        private Node next;
            
        private String getPropiedad(){
            return this.propiedad;
        }
        private void setPropiedad(String propiedad){
            this.propiedad = propiedad;
        }
        private Node getNext(){
            return this.next;
        }
        private void setNext(Node next){
            this.next =next;
        }
    }
  
    
}

